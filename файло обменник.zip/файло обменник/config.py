import os

class Config:
    # Токен бота от @BotFather
    BOT_TOKEN = "8373186823:AAGTMdqHR01a0fHoZBAqkmrKynrcVhownrM"  # Замените на реальный токен
    
    # Настройки базы данных
    DATABASE_NAME = 'file_exchange.db'